# Spatial Unity SDK Starter Template

A template to get you started building environments for Spatial.

Read more here: https://docs.spatial.io
